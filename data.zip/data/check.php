<?php
header('Access-Control-Allow-Origin:*');  
header('Content-Type: application/json; charset=UTF-8');  
header('Accept-Encoding: gzip, deflate');



$url = 'https://traffic.transportdata.tw/MOTC/v2/Road/Traffic/Live/ETag/Freeway?&$format=JSON';


$json = file_get_contents($url);

$jo = json_decode($json,true);
echo print_r($jo,1);

?>
